const socket=io()

var username;
let chat=document.querySelector('.chats')
let user_count=document.querySelector('.users-count')
let user_list=document.querySelector('.users-list')
let input_field=document.querySelector('#input-field')
let send_btn=document.querySelector('#send-btn')

do{
    username=prompt("enter your name")  
}while(!username)

socket.emit("new-user-joined",username)

socket.on("user-connected",(socket_name)=>{
    userjoinleft(socket_name,'joined')
})

socket.on("user-disconnected",(user)=>{
    userjoinleft(user,'left')
})

function userjoinleft(name,status){
    let div=document.createElement('div')
    div.classList.add('user-join')
    let content = ` <p><b>${name}</b> ${status} the chat</p>`
    div.innerHTML=content
    chat.appendChild(div)
    chat.scrollTop = chat.scrollHeight
}

socket.on('user-list',(users)=>{
    user_list.innerHTML=''
    users_arr=Object.values(users)
    for(i=0; i<=users_arr.length; i++){
        let p = document.createElement('p')
        p.innerText=users_arr[i]
        user_list.appendChild(p)
    }
    user_count.innerHTML=users_arr.length
})

send_btn.addEventListener('click',()=>{
    let data={
        user : username,
        msg  : input_field.value
    }
    if(input_field.value != ''){
        appendMessage(data,'outgoing')
        socket.emit('message',data)
        input_field.value=''
    }
})

function appendMessage(data,status){
    let div=document.createElement('div')
    div.classList.add('message',status)
    let content=`<h5>${data.user}</h5><p>${data.msg}</p>`
    div.innerHTML=content
    chat.appendChild(div)
    chat.scrollTop = chat.scrollHeight
}

socket.on('message',(data)=>{
    appendMessage(data,'incoming')
})