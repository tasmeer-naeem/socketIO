simple files:
index.html
index.css -> public folder
icons -> public folder

commands:
npm init ---> package.json
npm i express ---> node_modules
npm i nodemon -D ---> node_modules
npm i socket.io ---> node_modules 
to run file => nodemon index.js
to run file => npm run test
